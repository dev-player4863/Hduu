package git.artdeell.mojo.multirt;

import static git.artdeell.mojo.Tools.NATIVE_LIB_DIR;
import static org.apache.commons.io.FileUtils.listFiles;
import static org.apache.commons.io.FileUtils.write;

import android.system.Os;
import android.util.Log;

import com.kdt.mcgui.ProgressLayout;

import git.artdeell.mojo.R;
import git.artdeell.mojo.Tools;
import git.artdeell.mojo.utils.MathUtils;
import git.artdeell.mojo.utils.jre.JavaRunner;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class MultiRTUtils {

    private static final HashMap<String,Runtime> sCache = new HashMap<>();

    private static final File RUNTIME_FOLDER = new File(Tools.MULTIRT_HOME);
    private static final String JAVA_VERSION_STR = "JAVA_VERSION=\"";
    private static final String OS_ARCH_STR = "OS_ARCH=\"";

    public static List<Runtime> getRuntimes() {
        if(!RUNTIME_FOLDER.exists() && !RUNTIME_FOLDER.mkdirs()) {
            throw new RuntimeException("Failed to create runtime directory");
        }

        ArrayList<Runtime> runtimes = new ArrayList<>();
        File[] files = RUNTIME_FOLDER.listFiles();
        if(files != null) for(File f : files) {
            runtimes.add(read(f.getName()));
        }
        else throw new RuntimeException("The runtime directory does not exist");

        return runtimes;
    }

    public static String getExactJreName(int majorVersion) {
        List<Runtime> runtimes = getRuntimes();
        for(Runtime r : runtimes)
            if(r.javaVersion == majorVersion)return r.name;

        return null;
    }

    public static String getNearestJreName(int majorVersion) {
        List<Runtime> runtimes = getRuntimes();
        MathUtils.RankedValue<Runtime> nearestRankedRuntime = MathUtils.findNearestPositive(majorVersion, runtimes, (runtime)->runtime.javaVersion);
        if(nearestRankedRuntime == null) return null;
        Runtime nearestRuntime = nearestRankedRuntime.value;
        if(nearestRuntime == null) return null;
        return nearestRuntime.name;
    }

    public static void installRuntimeNamed(String nativeLibDir, InputStream runtimeInputStream, String name) throws IOException {
        File dest = new File(RUNTIME_FOLDER,"/"+name);
        if(dest.exists()) FileUtils.deleteDirectory(dest);
        try {
            uncompressTarXZ(runtimeInputStream, dest);
            runtimeInputStream.close();
            unpack200(nativeLibDir, RUNTIME_FOLDER + "/" + name);
            read(name);
        } finally {
            ProgressLayout.clearProgress(ProgressLayout.UNPACK_RUNTIME);
        }
    }

    public static void postPrepare(String name) throws IOException {
        File dest = new File(RUNTIME_FOLDER,"/" + name);
        if(!dest.exists()) return;

        Runtime runtime = read(name);
        File vmPath = JavaRunner.findVmPath(dest, runtime.arch);
        if(vmPath == null) throw new IOException("Could not find libjvm.so after extraction");
        File libDir = Objects.requireNonNull(vmPath.getParentFile()).getParentFile();

        File ftIn = new File(libDir, "libfreetype.so.6");
        File ftOut = new File(libDir,  "libfreetype.so");
        if (ftIn.exists() && (!ftOut.exists() || ftIn.length() != ftOut.length())) {
            if(!ftIn.renameTo(ftOut)) throw new IOException("Failed to rename freetype");
        }

        // Refresh libraries
        copyDummyNativeLib("libawt_xawt.so", libDir);
    }

    public static void installRuntimeNamedBinpack(InputStream universalFileInputStream, InputStream platformBinsInputStream, String name, String binpackVersion) throws IOException {
        File dest = new File(RUNTIME_FOLDER,"/"+name);
        if(dest.exists()) FileUtils.deleteDirectory(dest);
        try {
            installRuntimeNamedNoRemove(universalFileInputStream, dest);
            installRuntimeNamedNoRemove(platformBinsInputStream, dest);

            unpack200(NATIVE_LIB_DIR, RUNTIME_FOLDER + "/" + name);

            File binpack_verfile = new File(RUNTIME_FOLDER, "/" + name + "/pojav_version");
            write(binpack_verfile, binpackVersion, StandardCharsets.UTF_8);
            forceReread(name);
        } finally {
            ProgressLayout.clearProgress(ProgressLayout.UNPACK_RUNTIME);
        }
    }


    public static String readInternalRuntimeVersion(String name) {
        File versionFile = new File(RUNTIME_FOLDER,"/" + name + "/pojav_version");
        try {
            if (versionFile.exists()) {
                return Tools.read(versionFile.getAbsolutePath());
            }else{
                return null;
            }
        }catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static long readLastUpdateTime(String name) {
        File lastUpdateTimeFile = new File(RUNTIME_FOLDER, name+"/last_check_time");
        if(!lastUpdateTimeFile.exists()) return -1;
        try {
            return Long.parseLong(Tools.read(lastUpdateTimeFile).trim());
        }catch (IOException | NumberFormatException e) {
            return -1;
        }
    }

    public static void writeLastUpdateTime(String name, long time) {
        File lastUpdateTimeFile = new File(RUNTIME_FOLDER, name+"/last_check_time");
        try {
            Tools.write(lastUpdateTimeFile, Long.toString(time));
        }catch (IOException ignored) {}
    }

    public static void removeRuntimeNamed(String name) throws IOException {
        File dest = new File(RUNTIME_FOLDER,"/"+name);
        if(dest.exists()) {
            FileUtils.deleteDirectory(dest);
            sCache.remove(name);
        }
    }

    public static File getRuntimeHome(String name) {
        File dest = new File(RUNTIME_FOLDER, name);
        Log.i("MiltiRTUitls", "Dest exists? "+dest.exists());
        if((!dest.exists()) || MultiRTUtils.forceReread(name).versionString == null) throw new RuntimeException("Selected runtime is broken!");
        return dest;
    }

    public static Runtime forceReread(String name) {
        sCache.remove(name);
        return read(name);
    }

    public static Runtime read(String name) {
        Runtime returnRuntime = sCache.get(name);
        if(returnRuntime != null) return returnRuntime;
        File release = new File(RUNTIME_FOLDER,name+"/release");
        if(!release.exists()) {
            return new Runtime(name);
        }
        try {
            String content = Tools.read(release.getAbsolutePath());
            String javaVersion = Tools.extractUntilCharacter(content, JAVA_VERSION_STR, '"');
            String osArch = Tools.extractUntilCharacter(content, OS_ARCH_STR, '"');
            if(javaVersion != null && osArch != null) {
                String[] javaVersionSplit = javaVersion.split("\\.");
                int javaVersionInt;
                if (javaVersionSplit[0].equals("1")) {
                    javaVersionInt = Integer.parseInt(javaVersionSplit[1]);
                } else {
                    javaVersionInt = Integer.parseInt(javaVersionSplit[0]);
                }
                returnRuntime = new Runtime(name, javaVersion, osArch, javaVersionInt);
            }else{
                returnRuntime =  new Runtime(name);
            }
        }catch(IOException e) {
            returnRuntime =  new Runtime(name);
        }
        sCache.put(name, returnRuntime);
        return returnRuntime;
    }

    /**
     * Unpacks all .pack files into .jar Serves only for java 8, as java 9 brought project jigsaw
     * @param nativeLibraryDir The native lib path, required to execute the unpack200 binary
     * @param runtimePath The path to the runtime to walk into
     */
    private static void unpack200(String nativeLibraryDir, String runtimePath) {

        File basePath = new File(runtimePath);
        Collection<File> files = listFiles(basePath, new String[]{"pack"}, true);

        File workdir = new File(nativeLibraryDir);

        ProcessBuilder processBuilder = new ProcessBuilder().directory(workdir);
        for(File jarFile : files){
            try{
                Process process = processBuilder.command("./libunpack200.so", "-r", jarFile.getAbsolutePath(), jarFile.getAbsolutePath().replace(".pack", "")).start();
                process.waitFor();
            }catch (InterruptedException | IOException e) {
                Log.e("MULTIRT", "Failed to unpack the runtime !");
            }
        }
    }

    @SuppressWarnings("SameParameterValue")
    private static void copyDummyNativeLib(String name, File dest) throws IOException {
        File fileLib = new File(dest, name);
        FileInputStream is = new FileInputStream(new File(NATIVE_LIB_DIR, name));
        FileOutputStream os = new FileOutputStream(fileLib);
        IOUtils.copy(is, os);
        is.close();
        os.close();
    }

    private static void installRuntimeNamedNoRemove(InputStream runtimeInputStream, File dest) throws IOException {
        uncompressTarXZ(runtimeInputStream,dest);
        runtimeInputStream.close();
    }

    private static void uncompressTarXZ(final InputStream tarFileInputStream, final File dest) throws IOException {
        git.artdeell.mojo.utils.FileUtils.ensureDirectory(dest);

        byte[] buffer = new byte[8192];
        try(TarArchiveInputStream tarIn = new TarArchiveInputStream(new XZCompressorInputStream(tarFileInputStream))) {
            TarArchiveEntry tarEntry;
            // tarIn is a TarArchiveInputStream
            while ((tarEntry = tarIn.getNextTarEntry()) != null) {

                final String tarEntryName = tarEntry.getName();
                ProgressLayout.setProgress(ProgressLayout.UNPACK_RUNTIME, 100, R.string.global_unpacking, tarEntryName);

                File destPath = new File(dest, tarEntry.getName());
                git.artdeell.mojo.utils.FileUtils.ensureParentDirectory(destPath);
                if (tarEntry.isSymbolicLink()) {
                    try {
                        // android.system.Os
                        // Libcore one support all Android versions
                        Os.symlink(tarEntry.getName(), tarEntry.getLinkName());
                    } catch (Throwable e) {
                        Log.e("MultiRT", e.toString());
                    }
                } else if (tarEntry.isDirectory()) {
                    git.artdeell.mojo.utils.FileUtils.ensureDirectory(destPath);
                } else if (!destPath.exists() || destPath.length() != tarEntry.getSize()) {
                    FileOutputStream os = new FileOutputStream(destPath);
                    IOUtils.copyLarge(tarIn, os, buffer);
                    os.close();
                }
            }
        }
    }
}
